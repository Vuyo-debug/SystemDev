﻿namespace Group26
{


    partial class BookingsDS
    {
    }
}

namespace Group26.BookingsDSTableAdapters {
    
    
    public partial class BookingsTableAdapter {
    }
}
